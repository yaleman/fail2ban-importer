""" Downloads JSON-encoded lists from s3 or HTTPS endpoints and bans them

"""

__version__ = "0.0.4"
